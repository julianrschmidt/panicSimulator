function warningsOff( )
%WARNINGSOFF Summary of this function goes here
%   Detailed explanation goes here
warning('off', 'MATLAB:audiovideo:VideoWriter:noFramesWritten');

end

