function [ settings ] = setXMax( settings, xMax )
%SETXMAX Summary of this function goes here
%   Detailed explanation goes here
settings.xMax = xMax;

end

