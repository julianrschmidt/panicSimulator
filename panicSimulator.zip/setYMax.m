function [ settings ] = setYMax( settings, yMax )
%SETXMAX Summary of this function goes here
%   Detailed explanation goes here
settings.yMax = yMax;

end

